defmodule Draw.Repo do
  use Ecto.Repo, otp_app: :draw
end
