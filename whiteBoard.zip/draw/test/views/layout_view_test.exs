defmodule Draw.LayoutViewTest do
  use Draw.ConnCase, async: true
end
