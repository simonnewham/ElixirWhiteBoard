defmodule Draw.PageViewTest do
  use Draw.ConnCase, async: true
end
