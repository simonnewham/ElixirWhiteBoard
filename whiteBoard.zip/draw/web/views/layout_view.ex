defmodule Draw.LayoutView do
  use Draw.Web, :view
end
