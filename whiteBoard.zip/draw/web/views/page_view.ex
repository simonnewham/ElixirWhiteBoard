defmodule Draw.PageView do
  use Draw.Web, :view
end
